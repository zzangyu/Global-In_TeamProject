var clickMenuHandler = function(){
	var click = document.getElementsByClassName('wishList');
	for (var i = 0; i < click.length; i++){
    click[i].classList.toggle('btn-active');
	}
};