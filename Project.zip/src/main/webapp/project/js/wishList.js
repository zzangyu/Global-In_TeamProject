var mP = document.getElementById("mP");
var wL = document.getElementById("wL");
function myPlanClick() {
	mP.style.display = 'block';
	wL.style.display = 'none';
}
function wishListClick() {
	mP.style.display = 'none';
	wL.style.display = 'block';
}