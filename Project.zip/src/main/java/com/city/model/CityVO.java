package com.city.model;

public class CityVO {
	
	private String cityname = ""; 
	private String cityinfo = "";
	private String continent = "";
	private String longitude = "";
	private String latitude = "";
	private String info = "";
	private String volt = "";
	private String hour = "";
	private String timedifference = "";
	private String btn = "";
	
	
	public String getCityname() {
		return cityname;
	}
	public void setCityname(String cityname) {
		this.cityname = cityname;
	}
	public String getCityinfo() {
		return cityinfo;
	}
	public void setCityinfo(String cityinfo) {
		this.cityinfo = cityinfo;
	}
	public String getContinent() {
		return continent;
	}
	public void setContinent(String continent) {
		this.continent = continent;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getVolt() {
		return volt;
	}
	public void setVolt(String volt) {
		this.volt = volt;
	}
	public String getHour() {
		return hour;
	}
	public void setHour(String hour) {
		this.hour = hour;
	}
	public String getTimedifference() {
		return timedifference;
	}
	public void setTimedifference(String timedifference) {
		this.timedifference = timedifference;
	}
	public String getBtn() {
		return btn;
	}
	public void setBtn(String btn) {
		this.btn = btn;
	}
	
}
