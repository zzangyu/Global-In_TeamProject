package com.city.model;

public class PlanCityInfoVO {
	private String cityinfoname;
	private String citynameimg;
	private String cityinfoS;
	private String citypeakseason;
	private String citytwodays1;
	private String citytwodays2;
	private String citythreedays1;
	private String citythreedays2;
	private String citythreedays3;
	private String cityroute1;
	private String cityroute2;
	private String cityroute3;
	
	public String getCityinfoname() {
		return cityinfoname;
	}
	public void setCityinfoname(String cityinfoname) {
		this.cityinfoname = cityinfoname;
	}
	public String getCitynameimg() {
		return citynameimg;
	}
	public void setCitynameimg(String citynameimg) {
		this.citynameimg = citynameimg;
	}
	public String getCityinfoS() {
		return cityinfoS;
	}
	public void setCityinfoS(String cityinfoS) {
		this.cityinfoS = cityinfoS;
	}
	public String getCitypeakseason() {
		return citypeakseason;
	}
	public void setCitypeakseason(String citypeakseason) {
		this.citypeakseason = citypeakseason;
	}
	public String getCitytwodays1() {
		return citytwodays1;
	}
	public void setCitytwodays1(String citytwodays1) {
		this.citytwodays1 = citytwodays1;
	}
	public String getCitytwodays2() {
		return citytwodays2;
	}
	public void setCitytwodays2(String citytwodays2) {
		this.citytwodays2 = citytwodays2;
	}
	public String getCitythreedays1() {
		return citythreedays1;
	}
	public void setCitythreedays1(String citythreedays1) {
		this.citythreedays1 = citythreedays1;
	}
	public String getCitythreedays2() {
		return citythreedays2;
	}
	public void setCitythreedays2(String citythreedays2) {
		this.citythreedays2 = citythreedays2;
	}
	public String getCitythreedays3() {
		return citythreedays3;
	}
	public void setCitythreedays3(String citythreedays3) {
		this.citythreedays3 = citythreedays3;
	}
	public String getCityroute1() {
		return cityroute1;
	}
	public void setCityroute1(String cityroute1) {
		this.cityroute1 = cityroute1;
	}
	public String getCityroute2() {
		return cityroute2;
	}
	public void setCityroute2(String cityroute2) {
		this.cityroute2 = cityroute2;
	}
	public String getCityroute3() {
		return cityroute3;
	}
	public void setCityroute3(String cityroute3) {
		this.cityroute3 = cityroute3;
	}
	
	
}
