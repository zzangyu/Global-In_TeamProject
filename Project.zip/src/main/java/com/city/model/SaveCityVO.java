package com.city.model;

public class SaveCityVO {
	private String save_city_id;
	private String save_city_idCheck;
	private String save_city_eng; 
	private String save_city_kor;
	private String save_schedule;
	
	public String getSave_city_id() {
		return save_city_id;
	}
	public void setSave_city_id(String save_city_id) {
		this.save_city_id = save_city_id;
	}
	public String getSave_city_idCheck() {
		return save_city_idCheck;
	}
	public void setSave_city_idCheck(String save_city_idCheck) {
		this.save_city_idCheck = save_city_idCheck;
	}
	
	public String getSave_city_eng() {
		return save_city_eng;
	}
	public void setSave_city_eng(String save_city_eng) {
		this.save_city_eng = save_city_eng;
	}
	public String getSave_city_kor() {
		return save_city_kor;
	}
	public void setSave_city_kor(String save_city_kor) {
		this.save_city_kor = save_city_kor;
	}
	public String getSave_schedule() {
		return save_schedule;
	}
	public void setSave_schedule(String save_schedule) {
		this.save_schedule = save_schedule;
	}
	
}
